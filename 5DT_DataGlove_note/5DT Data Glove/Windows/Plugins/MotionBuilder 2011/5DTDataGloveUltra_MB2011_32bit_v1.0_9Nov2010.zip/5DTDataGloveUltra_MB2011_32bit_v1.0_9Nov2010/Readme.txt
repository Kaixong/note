
Windows XP:
Copy both DLL's into directory C:\Program Files\Autodesk\Autodesk MotionBuilder 2011 32-bit\bin\win32\plugins

Windows 7:
Copy both DLL's into directory C:\Program Files (x86)\Autodesk\Autodesk MotionBuilder 2011 32-bit\bin\win32\plugins



Read the Glove manual (available at http://www.5dt.com/downloads.html) on how to use the MotionBuilder plugin.