
Copy both DLL's into directory C:\Program Files\Autodesk\Autodesk MotionBuilder 2011 64-bit\bin\x64\plugins


Read the Glove manual (available at http://www.5dt.com/downloads.html) on how to use the MotionBuilder plugin.