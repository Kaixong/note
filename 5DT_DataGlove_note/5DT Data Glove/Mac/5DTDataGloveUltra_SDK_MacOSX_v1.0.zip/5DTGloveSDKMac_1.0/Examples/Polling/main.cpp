#include <iostream>
#include <iomanip>
#include <string>
#include "fglove.h"

using namespace std;

int main (int argc, char * const argv[]) 
{

	std::cout << "num USB found" << fdScanUSB() << "\n";

	fdGlove *pGlove = NULL;
	
	//a = fdOpen("DG5U_L"); //or you may use DG14U_R, DG14U_L, DG5U_R
	//a = fdOpen("DG14U_L");
	pGlove = fdOpen(""); // connects to the first glove it finds
	
	if (pGlove) 
	{
		cout<<"found glove \n";
		cout<<"type: "<<fdGetGloveType(pGlove)<<" handedness: "<<fdGetGloveHand(pGlove)<<"\n";
		cout<<"packet rate: "<<fdGetPacketRate(pGlove)<<"\n";
		cout<<"version number major: "<<fdGetFWVersionMajor(pGlove)<<"."<<fdGetFWVersionMinor(pGlove);
		
		for (int i=0; i<100000; i++)
		{
			for (int n=0; n<14;n++)
			{
				cout<<fixed<<setprecision(2)<<fdGetSensorScaled(pGlove, n)<<" ";
			}
			cout <<"\n";
		}
		
	}
	
	fdClose(pGlove);

    cout << "finished.\n";
    return 0;
}
