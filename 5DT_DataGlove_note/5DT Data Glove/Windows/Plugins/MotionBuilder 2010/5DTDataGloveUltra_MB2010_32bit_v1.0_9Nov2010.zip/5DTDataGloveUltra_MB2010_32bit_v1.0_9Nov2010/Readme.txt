
Copy both DLL's into directory C:\Program Files\Autodesk\MotionBuilder 2010\bin\win32\plugins.

Read the Glove manual (available at http://www.5dt.com/downloads.html) on how to use the MotionBuilder plugin.